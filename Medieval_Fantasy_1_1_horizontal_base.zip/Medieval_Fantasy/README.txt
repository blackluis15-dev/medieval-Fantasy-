MEDIEVAL FANTASY — VERSIÓN 1.0

Esta actualización renueva el paisaje del pueblo e incorpora una banda sonora diurna y nocturna.

MEJORAS DEL MAPA
- Árboles excluidos del río y de sus orillas; también se despejó el acceso al puente.
- Casas reubicadas más al norte para separarlas del agua.
- Más vegetación: arbustos, hierba alta y flores en zonas transitables.
- Texturas pixel-art renovadas para césped, caminos de tierra, orillas, agua, puentes, tejados, paredes y ventanas.
- La distribución de árboles y plantas es determinista: se mantiene igual entre cargas.

MÚSICA AMBIENTAL
DÍA (secuencial y en bucle):
1. Tavern Hearth at Dawn
2. Sunlight on Ancient Wood

NOCHE (secuencial y en bucle):
1. Under the Moonlit Pines
2. Lanterns Along the Path

El juego utiliza una sola instancia de audio: una pista termina antes de comenzar la siguiente, sin superposición. Al cambiar de día a noche o de noche a día, se reinicia la lista correspondiente. La música comienza al pulsar JUGAR, por las restricciones de reproducción automática de los navegadores. El botón ♫ del HUD permite silenciarla o activarla.

PWA / INSTALACIÓN
- Se conserva manifest.webmanifest y service-worker.js.
- La caché ahora incluye el nuevo módulo musical y las cuatro canciones para uso sin conexión tras completar la primera carga.
- Publica la carpeta completa Medieval_Fantasy en un alojamiento HTTPS y abre su URL en Chrome Android.
- Tras instalar la PWA, se puede abrir desde su icono sin iniciar Acode.

VERIFICACIÓN
- Se comprobaron las referencias de recursos del service worker y la sintaxis de los módulos JavaScript.
- No se ha realizado una prueba visual real en Chrome Android ni una prueba de audio en el dispositivo. Conviene probar el nuevo ZIP publicado y confirmar la posición de casas, vegetación y música en el teléfono.
