// Sistema de inventario: interfaz, selección y estado de apertura.
export function createInventory(){
 const itemList=[
  ['🪵','Madera','Un trozo de madera útil para fabricar objetos.'],
  ['🪨','Piedra','Una piedra resistente encontrada en el camino.'],
  ['🌿','Hierba','Una planta silvestre que crece en el pueblo.'],
  ['🍎','Manzana','Una fruta fresca y dulce.'],
  ['🧪','Poción','Una pequeña poción de aventura.'],
  ['🌼','Flor','Una flor recogida durante la exploración.']
 ];
 const slots=Array.from({length:24},(_,i)=>itemList[i]||null);
 let selectedSlot=-1, opened=false;
 function draw(){
  const grid=document.getElementById('inventory-grid');grid.innerHTML='';
  slots.forEach((item,i)=>{
   const b=document.createElement('button');b.className='slot'+(selectedSlot===i?' selected':'');
   b.innerHTML=item?item[0]:'<span style="opacity:.15">·</span>';
   if(item&&i<6)b.innerHTML+='<small>1</small>';
   b.addEventListener('click',()=>{selectedSlot=i;draw();document.getElementById('item-info').textContent=item?item[1]+': '+item[2]:'Este espacio está vacío.';});
   grid.appendChild(b);
  });
 }
 function open(){opened=true;draw();document.getElementById('inventory-screen').classList.remove('hidden');}
 function close(){opened=false;document.getElementById('inventory-screen').classList.add('hidden');}
 return {open,close,isOpen:()=>opened};
}
