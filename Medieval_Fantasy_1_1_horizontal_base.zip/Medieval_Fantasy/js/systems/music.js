// Reproductor ambiental: una sola instancia de Audio garantiza que nunca se mezclen pistas.
export function createMusicPlayer({dayTracks,nightTracks,volume=0.42,onStatus=()=>{}}) {
  const audio = new Audio();
  audio.preload = 'auto';
  audio.loop = false;
  audio.volume = Math.max(0,Math.min(1,volume));
  let enabled = true;
  let period = null;
  let trackIndex = 0;
  let tracks = [];
  let needsReload = true;

  function currentTrackName() {
    const path = tracks[trackIndex] || '';
    return path.split('/').pop().replace(/\.mp3$/i,'').replaceAll('_',' ');
  }
  function playCurrent() {
    if(!enabled || !tracks.length) return;
    audio.pause();
    audio.currentTime = 0;
    needsReload = false;
    audio.src = tracks[trackIndex];
    audio.load();
    const attempt = audio.play();
    if(attempt && typeof attempt.catch === 'function') {
      attempt.catch(() => onStatus('tap-required'));
    }
    onStatus('playing',currentTrackName(),period);
  }
  audio.addEventListener('ended',()=>{
    if(!enabled || !tracks.length) return;
    trackIndex=(trackIndex+1)%tracks.length;
    playCurrent();
  });

  function setPeriod(nextPeriod) {
    if(nextPeriod!=='day' && nextPeriod!=='night') return;
    if(period===nextPeriod) return;
    period=nextPeriod;
    tracks=period==='day'?dayTracks:nightTracks;
    trackIndex=0;
    if(enabled) playCurrent(); else needsReload=true;
  }
  function start(nextPeriod='day') {
    enabled=true;
    if(period===nextPeriod && audio.src && !needsReload) {
      const attempt=audio.play();
      if(attempt && typeof attempt.catch==='function') attempt.catch(()=>onStatus('tap-required'));
    } else {
      period=null;
      setPeriod(nextPeriod);
    }
    onStatus('enabled');
  }
  function toggle(nextPeriod='day') {
    if(enabled) {
      enabled=false;
      audio.pause();
      onStatus('muted');
    } else {
      enabled=true;
      if(period===nextPeriod && audio.src && !needsReload) {
        const attempt=audio.play();
        if(attempt && typeof attempt.catch==='function') attempt.catch(()=>onStatus('tap-required'));
      } else {
        period=null;
        setPeriod(nextPeriod);
      }
      onStatus('enabled');
    }
    return enabled;
  }
  function setVolume(value) { audio.volume=Math.max(0,Math.min(1,value)); }
  function stop() { audio.pause(); }
  return {start,setPeriod,toggle,setVolume,stop,isEnabled:()=>enabled,getPeriod:()=>period};
}
