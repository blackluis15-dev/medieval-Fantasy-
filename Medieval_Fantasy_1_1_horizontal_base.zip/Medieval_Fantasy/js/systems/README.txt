Aquí irán inventario, clima, reloj, guardado, diálogos y misiones.
