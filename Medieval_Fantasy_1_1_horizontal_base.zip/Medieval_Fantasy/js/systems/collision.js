// Colisiones del mundo exterior: edificios, árboles, río, puente y límites del mapa.
export function createCollisionSystem({T,mapW,mapH,player,buildings,trees,river}) {
  function collides(nx,ny) {
    const r={x:nx,y:ny,w:player.w,h:player.h};
    for(const b of buildings) {
      const bx=b.x*T,by=b.y*T,bw=b.w*T,bh=b.h*T;
      const overlaps=r.x<bx+bw&&r.x+r.w>bx&&r.y<by+bh&&r.y+r.h>by;
      const doorCenter=bx+bw/2;
      const inDoor=Math.abs((r.x+r.w/2)-doorCenter)<13&&r.y+r.h>by+bh-27;
      if(overlaps&&!inDoor)return true;
    }
    for(const t of trees) {
      const tx=t.x-7,ty=t.y-15;
      if(r.x<tx+22&&r.x+r.w>tx&&r.y<ty+20&&r.y+r.h>ty)return true;
    }
    const touchesRiver=r.y<river.y+river.h&&r.y+r.h>river.y;
    const onBridge=r.x+r.w>river.bridgeX+4&&r.x<river.bridgeX+river.bridgeW-4;
    if(touchesRiver&&!onBridge)return true;
    return nx<0||ny<0||nx>mapW*T-player.w||ny>mapH*T-player.h;
  }
  return {collides};
}
