// Controles de teclado y pantalla táctil.
export function bindMovementControls({keys,interact,openInventory,closeInventory,isInventoryOpen}){
 function bindButton(id,key){const el=document.getElementById(id);const on=e=>{e.preventDefault();keys[key]=true;};const off=e=>{e.preventDefault();keys[key]=false;};el.addEventListener('pointerdown',on);['pointerup','pointercancel','pointerleave'].forEach(ev=>el.addEventListener(ev,off));}
 bindButton('up','up');bindButton('down','down');bindButton('left','left');bindButton('right','right');
 document.getElementById('interact').addEventListener('pointerdown',e=>{e.preventDefault();interact();});
 window.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k==='i'){if(isInventoryOpen())closeInventory();else openInventory();}if(k==='escape'&&isInventoryOpen())closeInventory();if(k==='arrowup'||k==='w')keys.up=true;if(k==='arrowdown'||k==='s')keys.down=true;if(k==='arrowleft'||k==='a')keys.left=true;if(k==='arrowright'||k==='d')keys.right=true;if(k===' '||k==='enter')interact();});
 window.addEventListener('keyup',e=>{const k=e.key.toLowerCase();if(k==='arrowup'||k==='w')keys.up=false;if(k==='arrowdown'||k==='s')keys.down=false;if(k==='arrowleft'||k==='a')keys.left=false;if(k==='arrowright'||k==='d')keys.right=false;});
}
