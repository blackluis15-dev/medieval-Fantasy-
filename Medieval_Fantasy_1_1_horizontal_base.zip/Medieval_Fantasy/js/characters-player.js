// Renderizador del protagonista Zerbb usando una hoja de sprites 4x4.
// Filas: abajo, izquierda, derecha, arriba. Columnas: fotogramas de caminar.
export function createPlayerSpriteRenderer({ ctx, player, cam }) {
  const image = new Image();
  image.src = './assets/images/characters/zerbb-walk.png';
  let loaded = false;
  image.onload = () => { loaded = true; };
  const frameW = 72, frameH = 150;
  const draw = () => {
    const x = player.x - cam.x;
    const y = player.y - cam.y;
    if (!loaded) {
      // Fallback temporal mientras carga el PNG.
      ctx.fillStyle = '#315535'; ctx.fillRect(x - 2, y + 10, 16, 5);
      ctx.fillStyle = '#68452f'; ctx.fillRect(x + 1, y - 5, 10, 10);
      ctx.fillStyle = '#76533d'; ctx.fillRect(x, y + 3, 12, 8);
      return;
    }
    const row = ({ down: 0, left: 1, right: 2, up: 3 })[player.dir] ?? 0;
    const frame = player.moving ? Math.floor((player.animTime || 0) * 9) % 4 : 0;
    const drawW = 30, drawH = 46;
    const drawX = Math.round(x + player.w / 2 - drawW / 2);
    const drawY = Math.round(y + player.h - drawH + 3);
    // Sombra suave bajo los pies para integrarlo con el terreno.
    ctx.fillStyle = 'rgba(25, 35, 25, 0.28)';
    ctx.beginPath(); ctx.ellipse(x + player.w / 2, y + player.h + 1, 9, 3, 0, 0, Math.PI * 2); ctx.fill();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(image, frame * frameW, row * frameH, frameW, frameH, drawX, drawY, drawW, drawH);
  };
  return { draw, isLoaded: () => loaded };
}
