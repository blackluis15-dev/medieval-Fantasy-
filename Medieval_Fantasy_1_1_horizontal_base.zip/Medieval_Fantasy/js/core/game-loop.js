// Bucle principal: limita delta-time para evitar saltos bruscos.
export function startGameLoop(update,render){
 let last=0;
 function frame(timestamp){const dt=Math.min((timestamp-last)/1000||0,0.04);last=timestamp;update(dt);render(dt);requestAnimationFrame(frame);}
 requestAnimationFrame(frame);
}
