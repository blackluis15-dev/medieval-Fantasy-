Aquí separaremos el motor Canvas, cámara, entrada y bucle principal.
