// Renderizado del escenario e interiores con texturas pixel-art deterministas.
export function createRenderer({ctx,W,H,T,mapW,cam,river,worldClock,buildings,trees,vegetation=[]}) {
  function rect(x,y,w,h,c){
    ctx.fillStyle=c;
    ctx.fillRect(Math.round(x),Math.round(y),Math.max(1,Math.round(w)),Math.max(1,Math.round(h)));
  }
  const hash=(x,y,n=0)=>Math.abs((x*374761393+y*668265263+n*1442695041)>>>0);
  function drawGrass(){
    rect(0,0,W,H,'#527d43');
    const startX=Math.floor(cam.x/T),startY=Math.floor(cam.y/T);
    for(let ty=startY;ty<startY+Math.ceil(H/T)+2;ty++) for(let tx=startX;tx<startX+Math.ceil(W/T)+2;tx++){
      const x=tx*T-cam.x,y=ty*T-cam.y;
      const v=hash(tx,ty)%5;
      rect(x+2+(v%5),y+3,2,2,['#69964e','#416f3d','#789c55','#3e693a','#5b8846'][v]);
      if(hash(tx,ty,2)%4===0) rect(x+10,y+10,3,1,'#83a65d');
      if(hash(tx,ty,3)%7===0) rect(x+5,y+13,2,2,'#355f37');
      if(hash(tx,ty,4)%9===0) rect(x+1,y+8,2,1,'#9aa65b');
    }
  }
  function drawRiver(){
    const top=river.y-cam.y;
    // Orillas de tierra húmeda y pequeñas piedras.
    rect(0,top-5,mapW*T,5,'#8c8050');
    rect(0,top-3,mapW*T,2,'#b5a06b');
    rect(0,top+river.h,mapW*T,5,'#806f48');
    rect(0,top+river.h+3,mapW*T,2,'#b49a63');
    rect(0,top,mapW*T,river.h,'#286b8d');
    // Variaciones de profundidad y bandas de corriente.
    rect(0,top+5,mapW*T,2,'#347fa0');
    rect(0,top+river.h-5,mapW*T,2,'#205a7a');
    for(let i=0;i<46;i++){
      const wx=(i*97+worldClock.minutes*2.2)%(mapW*T);
      const x=wx-cam.x, y=top+3+(i*17%(river.h-5));
      const len=4+(i%4)*3;
      rect(x,y,len,1,i%3===0?'#a4d5d8':i%3===1?'#68b4c7':'#438eaa');
      if(i%4===0) rect(x+len+2,y+2,3,1,'#b8e0d8');
    }
    // Piedras pequeñas en las márgenes, lejos del paso del puente.
    for(let i=0;i<32;i++){
      const x=(i*131+53)%(mapW*T)-cam.x;
      if(x>river.bridgeX-cam.x-18&&x<river.bridgeX+river.bridgeW-cam.x+18) continue;
      rect(x,top-4+(i%2),3+(i%3),2,'#77775a');
      rect(x+1,top+river.h+1,3,2,'#77775a');
    }
  }
  function drawPaths(){
    // Camino principal de tierra apisonada con bordes irregulares.
    const y=17*T-cam.y;
    rect(0,y,mapW*T,5*T,'#987b50');
    rect(0,y+2,mapW*T,2,'#ad9060');
    for(let ty=0;ty<5;ty++) for(let tx=0;tx<mapW;tx++){
      const x=tx*T-cam.x,py=y+ty*T;
      const n=hash(tx,ty,8)%6;
      rect(x+2+n,py+3+(n%4),2,2,n%2?'#806744':'#b99b69');
      if(n===0) rect(x+10,py+11,3,1,'#c6a978');
      if(n===3) rect(x+5,py+7,2,2,'#6f6045');
    }
    // Sendero vertical y ramales cortos hacia las casas.
    const vx=19*T-cam.x;
    rect(vx,0,4*T,H,'#987b50');
    rect(vx+2,0,2,H,'#ad9060');
    for(let ty=0;ty<mapH;ty++) for(let tx=19;tx<23;tx++){
      const n=hash(tx,ty,12)%5;
      rect(tx*T-cam.x+3+n,ty*T-cam.y+5,2,2,n%2?'#806744':'#b99b69');
    }
    // Ramales de acceso hacia las fachadas, sin invadir el río.
    buildings.forEach(b=>{
      const bx=(b.x+b.w/2)*T-cam.x;
      const by=(b.y+b.h)*T-cam.y;
      rect(bx-3,by,6,Math.max(0,17*T-(b.y+b.h)*T),'#987b50');
      for(let k=0;k<Math.max(0,17*T-(b.y+b.h)*T);k+=9) rect(bx-1,by+k,2,2,'#b99b69');
    });
  }
  function drawBridge(){
    const x=river.bridgeX-cam.x,y=river.y-cam.y,w=river.bridgeW,h=river.h;
    rect(x-3,y-2,w+6,h+4,'#493a2c');
    rect(x,y,w,h,'#795438');
    for(let py=0;py<h;py+=6){
      rect(x+1,y+py,w-2,4,py%12===0?'#a8794e':'#93643f');
      rect(x+2,y+py+4,w-4,1,'#563c2c');
      for(let px=5;px<w-4;px+=17) rect(x+px,y+py+1,1,1,'#d0a16a');
    }
    rect(x,y,w,2,'#d0a06a');rect(x,y+h-2,w,2,'#d0a06a');
    rect(x-2,y-2,3,h+4,'#563d2c');rect(x+w-1,y-2,3,h+4,'#563d2c');
  }
  function drawBuilding(b){
    const x=b.x*T-cam.x,y=b.y*T-cam.y,w=b.w*T,h=b.h*T;
    // Sombra y cimientos de piedra.
    rect(x+4,y+h-3,w,6,'#34432d');
    rect(x+2,y+h-8,w-4,8,'#766b57');
    for(let k=0;k<w-5;k+=13) rect(x+4+k,y+h-7,7,2,'#a69a7b');
    // Paredes con entramado de madera y piedra irregular.
    rect(x,y+20,w,h-25,b.wall);
    rect(x+3,y+23,w-6,h-29,'#d7c69c');
    for(let py=29;py<h-8;py+=13){
      rect(x+4,y+py,w-8,1,'#b39b72');
      for(let px=8;px<w-8;px+=19) rect(x+px,y+py+3,5,2,'#c3ad82');
    }
    rect(x+3,y+22,3,h-26,'#654a36');rect(x+w-6,y+22,3,h-26,'#654a36');
    // Tejado de tejas en filas alternadas.
    rect(x-6,y+3,w+12,23,b.roof);
    rect(x-8,y,w+16,8,'#47352c');
    for(let row=0;row<2;row++) for(let px=0;px<w+8;px+=10){
      const ox=(row%2)*5;
      rect(x-4+px+ox,y+5+row*9,8,5,row===0?'#a45a43':b.roof);
      rect(x-4+px+ox,y+5+row*9,7,1,'#c0805b');
    }
    rect(x-7,y+22,w+14,3,'#4d392d');
    // Vigas decorativas.
    rect(x+5,y+24,3,h-30,'#684b35');rect(x+w-8,y+24,3,h-30,'#684b35');
    rect(x+5,y+34,w-10,2,'#79583a');
    // Puerta y ventanas.
    const doorX=x+w/2-7;
    rect(doorX-2,y+h-25,18,25,'#493426');
    rect(doorX,y+h-23,14,23,'#754a32');
    rect(doorX+2,y+h-21,10,19,'#986744');
    rect(doorX+10,y+h-13,2,2,'#e1bd68');
    for(const wx of [x+12,x+w-25]){
      rect(wx-2,y+33,16,14,'#5c4533');
      rect(wx,y+35,12,10,'#6f9ba0');
      rect(wx+5,y+35,2,10,'#e0d1a5');rect(wx,y+39,12,2,'#e0d1a5');
      rect(wx+1,y+34,10,1,'#c3d8c5');
    }
    // Letrero sencillo para la posada y la tienda.
    if(b.style==='inn'||b.style==='shop'){
      rect(x+w/2-10,y+27,20,6,'#4b3528');
      rect(x+w/2-8,y+28,16,4,b.style==='inn'?'#d0ae69':'#9cae9a');
      rect(x+w/2-1,y+28,2,4,'#49372b');
    }
  }
  function drawTree(t){
    const x=t.x-cam.x,y=t.y-cam.y,v=t.variant||0;
    const leaf=[['#245536','#367548','#568b4c'],['#315b35','#477b3d','#78964a'],['#1f4b3b','#326c50','#63945a']][v%3];
    rect(x-8,y+7,20,5,'#315b37');
    rect(x-2,y-3,8,15,'#725039');
    rect(x-10,y-13,24,17,leaf[0]);
    rect(x-7,y-20,19,13,leaf[1]);
    rect(x-3,y-24,12,9,leaf[0]);
    rect(x-5,y-16,5,4,leaf[2]);rect(x+5,y-9,4,3,leaf[2]);
    rect(x-10,y-4,5,4,leaf[1]);rect(x+10,y-18,4,4,leaf[2]);
  }
  function drawVegetation(v){
    const x=v.x-cam.x,y=v.y-cam.y,n=v.variant||0;
    if(v.type==='bush'){
      rect(x,y+4,12,4,'#294c31');
      rect(x+1,y,7,7,['#285c39','#356b3d','#416f3d','#2c6648'][n]);
      rect(x+6,y-2,7,8,['#367447','#4b8044','#568a4d','#377a55'][n]);
      rect(x+3,y+1,2,2,'#83a65b');
    }else if(v.type==='grass'){
      rect(x+2,y+4,1,5,'#b3a75f');rect(x+5,y+1,1,7,'#8eaa59');
      rect(x+8,y+3,1,5,'#d0bb69');rect(x+4,y+6,4,1,'#52763d');
    }else{
      rect(x+4,y+3,1,5,'#477342');
      const colors=['#f0d66d','#e7a1ae','#eee8d5','#b8a0d5'];
      rect(x+2,y+1,3,3,colors[n]);rect(x+5,y,3,3,colors[(n+1)%4]);
      rect(x+4,y+2,2,2,'#e9d28b');
    }
  }
  function drawWorld(){
    drawGrass();
    drawRiver();
    drawPaths();
    drawBridge();
    vegetation.forEach(drawVegetation);
    buildings.forEach(drawBuilding);
    trees.forEach(drawTree);
    // Cercas y postes rústicos al sur del pueblo.
    for(let x=5;x<10;x++){
      const px=x*T-cam.x,py=25*T-cam.y;
      rect(px,py,3,16,'#725137');rect(px,py+9,16,2,'#ad8756');
      rect(px-1,py-2,5,3,'#b38c59');
    }
  }
  function drawInterior(building){
    rect(0,0,W,H,'#392b25');rect(12,12,W-24,H-24,'#9a704c');
    for(let y=20;y<H-20;y+=18)rect(14,y,W-28,2,'#805638');
    rect(151,111,178,105,'#7d3e43');rect(158,118,164,91,'#b66b55');rect(166,126,148,75,'#7d3e43');
    rect(196,145,88,34,'#68452f');rect(202,150,76,24,'#a8794c');rect(184,151,10,22,'#68452f');rect(286,151,10,22,'#68452f');
    rect(35,42,83,57,'#62452f');rect(40,47,73,47,'#e0d1ad');rect(43,50,28,18,'#f0e7d1');rect(75,50,35,39,'#7c91a0');
    rect(210,22,60,8,'#563a2a');rect(216,27,48,22,'#6b9aa4');rect(237,27,3,22,'#e3cf9e');rect(216,36,48,3,'#e3cf9e');
    rect(365,35,70,62,'#604333');rect(374,44,52,45,'#382b28');rect(389,62,22,23,'#e58c43');rect(395,68,10,17,'#ffd078');
    rect(350,122,82,9,'#62452f');rect(357,106,12,16,'#bd945e');rect(379,108,18,14,'#9c6542');rect(406,103,13,19,'#6e7c59');
    rect(218,270,44,28,'#563a2a');rect(224,274,32,24,'#a8794c');
    ctx.fillStyle='#fff0ce';ctx.font='bold 11px system-ui';ctx.textAlign='center';ctx.fillText(building?building.name:'Interior',W/2,13);ctx.textAlign='left';
  }
  return {drawWorld,drawInterior};
}
