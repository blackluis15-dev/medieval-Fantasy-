Aquí irán mapa, terreno, edificios, interiores y generación del mundo.
