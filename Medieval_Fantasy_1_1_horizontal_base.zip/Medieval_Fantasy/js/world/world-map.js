// Datos del mapa: terreno, edificios, vegetación y río.
// Las posiciones se generan con una semilla fija para que el pueblo no cambie al recargar.
export function createWorldMap({T, mapW, mapH}) {
  const world = [];
  for (let y=0; y<mapH; y++) {
    world[y]=[];
    for (let x=0; x<mapW; x++) world[y][x]=((x*17+y*31)%11===0)?1:0;
  }

  // Casas reubicadas hacia el norte: quedan dos o más casillas de terreno antes del río.
  const buildings = [
    {x:9,y:4,w:7,h:5,name:'Casa del pueblo',roof:'#874536',wall:'#c9ad79',style:'cottage'},
    {x:27,y:5,w:8,h:6,name:'Posada La Bellota',roof:'#654331',wall:'#d1bd91',style:'inn'},
    {x:43,y:4,w:7,h:5,name:'Tienda',roof:'#4d6170',wall:'#cdbb91',style:'shop'}
  ];

  const obstacles=buildings.map(b=>({x:b.x*T,y:b.y*T,w:b.w*T,h:b.h*T,name:b.name}));
  const river={y:13*T,h:3*T,bridgeX:19*T,bridgeW:4*T};
  const trees=[];
  const vegetation=[];
  const inRiverBuffer=(x,y)=>y>=11&&y<=18; // agua + orillas despejadas
  const onRoad=(x,y)=>(y>=17&&y<=22)||(x>=18&&x<=22);
  const nearBuilding=(x,y)=>buildings.some(b=>
    x>=b.x-2&&x<=b.x+b.w+1&&y>=b.y-2&&y<=b.y+b.h+1
  );
  const bridgeAccess=(x,y)=>x>=17&&x<=24&&y>=11&&y<=18;

  // Bosques más abundantes, pero nunca sobre el río, el puente, caminos o casas.
  for(let y=2;y<mapH-2;y++) for(let x=2;x<mapW-2;x++) {
    if(inRiverBuffer(x,y)||onRoad(x,y)||nearBuilding(x,y)||bridgeAccess(x,y)) continue;
    const seed=(x*73+y*151+x*y*17)%100;
    if(seed<17) {
      trees.push({x:x*T+8,y:y*T+10,variant:(x*3+y*5)%3});
    }
  }

  // Matorrales, hierba alta y flores distribuidos por zonas transitables.
  for(let y=2;y<mapH-2;y++) for(let x=2;x<mapW-2;x++) {
    if(inRiverBuffer(x,y)||onRoad(x,y)||nearBuilding(x,y)||bridgeAccess(x,y)) continue;
    const seed=(x*29+y*47+x*y*11)%100;
    if(seed<24) {
      vegetation.push({
        x:x*T+((x*7+y*3)%9),
        y:y*T+((x*5+y*11)%9),
        type:seed<9?'bush':seed<17?'grass':'flower',
        variant:(x+y*2)%4
      });
    }
  }

  return {world,buildings,obstacles,trees,vegetation,river};
}
