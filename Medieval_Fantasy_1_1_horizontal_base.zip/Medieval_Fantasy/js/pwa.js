// Registro PWA e instalación opcional desde el menú del juego.
(() => {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./service-worker.js')
        .then(() => console.info('Medieval Fantasy: modo PWA preparado.'))
        .catch((error) => console.warn('No se pudo registrar el modo sin conexión:', error));
    });
  }

  let installPrompt = null;
  const installButton = document.getElementById('install-app');
  if (!installButton) return;

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    installPrompt = event;
    installButton.classList.remove('hidden');
  });

  installButton.addEventListener('click', async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    await installPrompt.userChoice;
    installPrompt = null;
    installButton.classList.add('hidden');
  });

  window.addEventListener('appinstalled', () => {
    installButton.classList.add('hidden');
    const message = document.getElementById('menu-message');
    if (message) message.textContent = '¡Medieval Fantasy se instaló correctamente!';
  });
})();
