
import { createInventory } from './systems/inventory.js';
import { bindMovementControls } from './systems/controls.js';
import { startGameLoop } from './core/game-loop.js';
import { createWorldMap } from './world/world-map.js';
import { createRenderer } from './core/renderer.js';
import { createCollisionSystem } from './systems/collision.js';
import { createPlayerSpriteRenderer } from './characters-player.js';
import { createMusicPlayer } from './systems/music.js';

(() => {
 const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
 const W=480,H=320,T=16, mapW=60,mapH=45;
 let cam={x:0,y:0}, toastTimer=0;
 let gameStarted=false;
 const inventory=createInventory();
 // Tiempo del mundo: un día completo del juego dura 12 minutos reales.
 const worldClock={minutes:8*60,day:1,secondsPerGameMinute:0.5};
 let weather='clear', eclipse=null, weatherName='Despejado';
 const clouds=Array.from({length:7},(_,i)=>({x:i*95+25,y:28+(i*37)%105,s:0.65+(i%3)*0.2,speed:5+i%3}));
 const rain=Array.from({length:90},(_,i)=>({x:(i*53)%480,y:(i*29)%320,speed:100+(i%5)*22}));
 let weatherChangedDay=1;
 const player={x:15*T,y:19*T,w:12,h:13,speed:88,dir:'down',moving:false};
 let currentBuilding=null, outsidePosition=null;
 const keys={up:false,down:false,left:false,right:false};
 const map=createWorldMap({T,mapW,mapH});
 const {world,buildings,obstacles,trees,river}=map;
 const renderer=createRenderer({ctx,W,H,T,mapW,cam,river,worldClock,buildings,trees,vegetation:map.vegetation});
 const collision=createCollisionSystem({T,mapW,mapH,player,buildings,trees,river});
 const playerSprites=createPlayerSpriteRenderer({ctx,player,cam});
 const music=createMusicPlayer({
   dayTracks:[
     './assets/audio/tavern_hearth_at_dawn.mp3',
     './assets/audio/sunlight_on_ancient_wood.mp3'
   ],
   nightTracks:[
     './assets/audio/under_the_moonlit_pines.mp3',
     './assets/audio/lanterns_along_the_path.mp3'
   ],
   volume:0.42
 });
 const musicPeriod=()=>((worldClock.minutes/60)>=6&&(worldClock.minutes/60)<18?'day':'night');
 function rect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}

 function interiorCollides(nx,ny){
   if(nx<22||ny<24||nx+player.w>W-22||ny+player.h>H-28)return true;
   const r={x:nx,y:ny,w:player.w,h:player.h};
   const furniture=[
     {x:35,y:42,w:83,h:57},{x:184,y:145,w:112,h:34},
     {x:365,y:35,w:70,h:62},{x:350,y:106,w:82,h:25}
   ];
   return furniture.some(o=>r.x<o.x+o.w&&r.x+r.w>o.x&&r.y<o.y+o.h&&r.y+r.h>o.y);
 }
 function enterBuilding(b){
   outsidePosition={x:player.x,y:player.y,dir:player.dir};
   currentBuilding=b;
   player.x=234;player.y=238;player.dir='up';
   keys.up=keys.down=keys.left=keys.right=false;
   say('🏡 Has entrado en '+b.name);
 }
 function leaveBuilding(){
   currentBuilding=null;
   if(outsidePosition){player.x=outsidePosition.x;player.y=outsidePosition.y+15;player.dir='down';}
   outsidePosition=null;
   say('🚪 Has salido al pueblo');
 }
 function chooseWeather(){
   // Los eclipses son fenómenos poco frecuentes; el resto de días puede estar despejado, nublado o lluvioso.
   const roll=Math.random();
   if(roll<0.018){eclipse='solar';weather='clear';weatherName='Eclipse solar';}
   else if(roll<0.036){eclipse='lunar';weather='clear';weatherName='Eclipse lunar';}
   else {eclipse=null;weather=roll<0.48?'clear':roll<0.77?'cloudy':'rain';weatherName=weather==='clear'?'Despejado':weather==='cloudy'?'Nublado':'Lluvia';}
   weatherChangedDay=worldClock.day;
   say(eclipse==='solar'?'🌑 Un eclipse solar se aproxima...':eclipse==='lunar'?'🌕 Esta noche habrá un eclipse lunar':weather==='rain'?'🌧️ Se aproxima la lluvia':weather==='cloudy'?'☁️ El cielo se está nublando':'☀️ El cielo está despejado');
 }
 function timeLabel(){const h=Math.floor(worldClock.minutes/60)%24,m=Math.floor(worldClock.minutes%60);return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');}
 function nightAmount(){
   const h=worldClock.minutes/60;
   if(h>=7&&h<18)return 0;
   if(h>=18&&h<20)return (h-18)/2*0.72;
   if(h>=20||h<5)return 0.72;
   if(h>=5&&h<7)return (1-(h-5)/2)*0.72;
   return 0;
 }
 function drawCloud(x,y,s){
   ctx.fillStyle='#d8e0d5';ctx.globalAlpha=weather==='rain'?0.78:0.66;
   ctx.fillRect(x,y,38*s,10*s);ctx.fillRect(x+7*s,y-7*s,17*s,14*s);ctx.fillRect(x+21*s,y-4*s,15*s,12*s);
   ctx.globalAlpha=1;
 }
 function drawAtmosphere(dt){
   const h=worldClock.minutes/60, night=nightAmount();
   // Sol y luna viajan por el cielo según la hora.
   const daylight=Math.max(0,Math.min(1,(h-6)/12));
   const sx=35+daylight*410, sy=112-Math.sin(daylight*Math.PI)*75;
   const isSolar=eclipse==='solar'&&h>=10&&h<=15;
   const isLunar=eclipse==='lunar'&&(h>=19||h<=5);
   if(h>=6&&h<19){
     ctx.fillStyle=isSolar?'#332f3d':'#ffe58a';ctx.beginPath();ctx.arc(sx,sy,isSolar?13:10,0,Math.PI*2);ctx.fill();
     if(isSolar){ctx.strokeStyle='#e4d8bd';ctx.lineWidth=3;ctx.beginPath();ctx.arc(sx,sy,17,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#171827';ctx.beginPath();ctx.arc(sx,sy,10,0,Math.PI*2);ctx.fill();}
   }else{
     const moonX=420-(Math.max(0,h-19)/5)*360;
     ctx.fillStyle='#f2edc9';ctx.beginPath();ctx.arc(moonX,62,9,0,Math.PI*2);ctx.fill();
     if(isLunar){ctx.fillStyle='#6d2638';ctx.beginPath();ctx.arc(moonX,62,9,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#d18a70';ctx.lineWidth=2;ctx.beginPath();ctx.arc(moonX,62,13,0,Math.PI*2);ctx.stroke();}
   }
   if(weather==='cloudy'||weather==='rain'||eclipse==='solar'){
     clouds.forEach(c=>{c.x-=c.speed*dt;if(c.x<-55)c.x=500;drawCloud(c.x,c.y-cam.y*0.08,c.s);});
   }
   // Capa de noche y penumbra de amanecer/atardecer.
   if(night>0){ctx.fillStyle=`rgba(12,20,49,${night})`;ctx.fillRect(0,0,W,H);}
   if(weather==='cloudy') {ctx.fillStyle='rgba(75,83,94,0.18)';ctx.fillRect(0,0,W,H);}
   if(weather==='rain'){
     ctx.fillStyle='rgba(34,48,68,0.22)';ctx.fillRect(0,0,W,H);
     ctx.strokeStyle='#b7d6e4';ctx.globalAlpha=0.62;ctx.lineWidth=1;
     rain.forEach(r=>{r.y+=r.speed*dt;r.x-=35*dt;if(r.y>H){r.y=-8;r.x=Math.random()*W;}if(r.x<0)r.x=W;ctx.beginPath();ctx.moveTo(r.x,r.y);ctx.lineTo(r.x-3,r.y+7);ctx.stroke();});
     ctx.globalAlpha=1;
   }
   if(isSolar&&h>=10&&h<=15){ctx.fillStyle='rgba(10,10,20,0.32)';ctx.fillRect(0,0,W,H);}
   const period=h>=6&&h<18?'DÍA':'NOCHE';
   document.getElementById('period-label').textContent=period;
   document.getElementById('period-icon').textContent=isSolar?'🌑':isLunar?'🔴':period==='DÍA'?(weather==='rain'?'🌧️':weather==='cloudy'?'☁️':'☀️'):(weather==='rain'?'🌧️':'🌙');
   document.getElementById('weather-label').textContent=weatherName;
   document.getElementById('clock-label').textContent=timeLabel();
   document.getElementById('hint').textContent=`Día ${worldClock.day} · ${timeLabel()}`;
 }
 function drawPlayer(){playerSprites.draw();}

 function say(msg){const el=document.getElementById('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),1900);}
 function interact(){
   if(currentBuilding){leaveBuilding();return;}
   const px=player.x+player.w/2,py=player.y+player.h/2;
   let nearest=null,dist=Infinity;
   for(const b of buildings){
     const bx=(b.x+b.w/2)*T,by=(b.y+b.h)*T;
     const d=Math.hypot(px-bx,py-by);
     if(d<dist){dist=d;nearest=b;}
   }
   if(nearest&&dist<62){enterBuilding(nearest);return;}
   const riverDist=Math.abs(py-(river.y+river.h/2));
   if(riverDist<30&&!(px>river.bridgeX&&px<river.bridgeX+river.bridgeW)){
     say('🌊 El río es demasiado profundo. Busca el puente.');return;
   }
   say('🌼 Has explorado un rincón del pueblo.');
 }
 function update(dt){
   if(!gameStarted || inventory.isOpen()){keys.up=keys.down=keys.left=keys.right=false;return;}
   worldClock.minutes+=dt/worldClock.secondsPerGameMinute;
   music.setPeriod(musicPeriod());
   if(worldClock.minutes>=1440){worldClock.minutes-=1440;worldClock.day++;chooseWeather();}
   let dx=(keys.right?1:0)-(keys.left?1:0),dy=(keys.down?1:0)-(keys.up?1:0);
   player.moving=!!(dx||dy);
   player.animTime=(player.animTime||0)+dt;
   if(dx||dy){let l=Math.hypot(dx,dy);dx=dx/l;dy=dy/l;
     if(Math.abs(dx)>Math.abs(dy))player.dir=dx>0?'right':'left';else player.dir=dy>0?'down':'up';
     let nx=player.x+dx*player.speed*dt,ny=player.y+dy*player.speed*dt;
     if(currentBuilding){
       if(!interiorCollides(nx,player.y))player.x=nx;
       if(!interiorCollides(player.x,ny))player.y=ny;
     }else{
       if(!collision.collides(nx,player.y))player.x=nx;
       if(!collision.collides(player.x,ny))player.y=ny;
     }
   }
   if(!currentBuilding){
     cam.x=Math.max(0,Math.min(mapW*T-W,player.x-W/2));
     cam.y=Math.max(0,Math.min(mapH*T-H,player.y-H/2));
   }else{cam.x=0;cam.y=0;}
 }
 function render(dt=0){
   ctx.clearRect(0,0,W,H);
   if(currentBuilding){renderer.drawInterior(currentBuilding);drawPlayer();}
   else{renderer.drawWorld();drawAtmosphere(dt);drawPlayer();}
 }

 const mainMenu=document.getElementById('main-menu');
 const inventoryScreen=document.getElementById('inventory-screen');
 const openInventory=()=>{
   if(!gameStarted||currentBuilding||inventory.isOpen())return;
   inventory.open();
 };
 const closeInventory=()=>inventory.close();
 document.getElementById('start-game').addEventListener('click',()=>{
   gameStarted=true;mainMenu.classList.add('hidden');music.start(musicPeriod());say('¡Tu aventura comienza!');
 });
 document.getElementById('inventory-open').addEventListener('click',openInventory);
 document.getElementById('music-toggle').addEventListener('click',()=>{
   const enabled=music.toggle(musicPeriod());
   const button=document.getElementById('music-toggle');
   button.textContent=enabled?'♫':'♪';
   button.setAttribute('aria-label',enabled?'Silenciar música':'Activar música');
   say(enabled?'🎵 Música activada':'🔇 Música silenciada');
 });
 document.getElementById('inventory-close').addEventListener('click',closeInventory);
 document.getElementById('options-button').addEventListener('click',()=>{
   document.getElementById('menu-message').textContent='Opciones: controles táctiles y teclado disponibles. Más ajustes llegarán pronto.';
 });
 document.getElementById('credits-button').addEventListener('click',()=>{
   document.getElementById('menu-message').textContent='Medieval Fantasy · Un mundo original creado paso a paso.';
 });

 startGameLoop(update,render);
 bindMovementControls({keys,interact,openInventory,closeInventory,isInventoryOpen:()=>inventory.isOpen()});
 chooseWeather();say('¡Bienvenido a tu primer mundo!');
})();
