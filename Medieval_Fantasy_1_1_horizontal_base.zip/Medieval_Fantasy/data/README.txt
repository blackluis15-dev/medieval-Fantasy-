Datos del juego: objetos, diálogos, NPC, configuración y partidas.
