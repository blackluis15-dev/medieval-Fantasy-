const CACHE_NAME = 'medieval-fantasy-pwa-v1.0';
const APP_FILES = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./css/style.css",
  "./js/pwa.js",
  "./js/main.js",
  "./js/characters-player.js",
  "./js/core/game-loop.js",
  "./js/core/renderer.js",
  "./js/systems/controls.js",
  "./js/systems/inventory.js",
  "./js/systems/collision.js",
  "./js/systems/music.js",
  "./js/world/world-map.js",
  "./assets/images/logo/medieval-fantasy-logo.png",
  "./assets/images/characters/zerbb-walk.png",
  "./assets/images/icons/medieval-fantasy-192.png",
  "./assets/images/icons/medieval-fantasy-512.png",
  "./assets/audio/tavern_hearth_at_dawn.mp3",
  "./assets/audio/sunlight_on_ancient_wood.mp3",
  "./assets/audio/under_the_moonlit_pines.mp3",
  "./assets/audio/lanterns_along_the_path.mp3"
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(APP_FILES);
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith('medieval-fantasy-pwa-') && key !== CACHE_NAME).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        const cache = await caches.open(CACHE_NAME);
        cache.put('./index.html', response.clone());
        return response;
      } catch (_) {
        return (await caches.match('./index.html')) || (await caches.match('./'));
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response && response.ok) {
        const cache = await caches.open(CACHE_NAME);
        cache.put(request, response.clone());
      }
      return response;
    } catch (error) {
      throw error;
    }
  })());
});
