Música y efectos de sonido.
