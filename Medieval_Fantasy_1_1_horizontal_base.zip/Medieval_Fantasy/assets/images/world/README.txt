Tilesets, edificios, árboles y escenarios.
