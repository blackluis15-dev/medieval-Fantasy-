Sprites de personajes y animaciones.
