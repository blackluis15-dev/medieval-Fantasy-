import { Engine } from './Engine.js';

window.addEventListener('DOMContentLoaded', () => {
    const app = new Engine('mainCanvas');
});