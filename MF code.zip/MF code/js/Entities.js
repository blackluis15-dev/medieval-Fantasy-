export class Player {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 32;
        this.height = 42;
        this.speed = 3.5;
        this.vx = 0;
        this.vy = 0;
    }

    update(input) {
        this.vx = 0;
        this.vy = 0;

        if (input.isPressed('ArrowRight') || input.isPressed('KeyD')) this.vx = this.speed;
        if (input.isPressed('ArrowLeft') || input.isPressed('KeyA')) this.vx = -this.speed;
        if (input.isPressed('ArrowDown') || input.isPressed('KeyS')) this.vy = this.speed;
        if (input.isPressed('ArrowUp') || input.isPressed('KeyW')) this.vy = -this.speed;

        this.x += this.vx;
        this.y += this.vy;
    }
}

export class Tree {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 60;
        this.height = 90;
        this.health = 3;
        this.hasFruit = true;
    }

    chop() {
        if (this.health > 0) {
            this.health--;
            return true;
        }
        return false;
    }
}

export class House {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 120;
        this.height = 100;
    }
}

export class Crop {
    constructor(x, y, type) {
        this.x = x;
        this.y = y;
        this.width = 32;
        this.height = 32;
        this.type = type;
        this.stage = 0;
        this.growthTimer = 0;
        this.maxGrowthTime = 300;
    }

    update() {
        if (this.stage < 2) {
            this.growthTimer++;
            if (this.growthTimer > this.maxGrowthTime / 2 && this.stage === 0) {
                this.stage = 1;
            }
            if (this.growthTimer >= this.maxGrowthTime && this.stage === 1) {
                this.stage = 2;
            }
        }
    }
}

export class ItemDrop {
    constructor(x, y, itemName, amount = 1) {
        this.x = x;
        this.y = y;
        this.width = 16;
        this.height = 16;
        this.itemName = itemName;
        this.amount = amount;
    }
}