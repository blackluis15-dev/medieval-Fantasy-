export class InputHandler {
    constructor() {
        this.keys = {};
        this.listeners = {};

        window.addEventListener('keydown', (e) => {
            this.keys[e.code] = true;
            if (this.listeners[e.code]) {
                this.listeners[e.code].forEach(callback => callback());
            }
        });

        window.addEventListener('keyup', (e) => {
            this.keys[e.code] = false;
        });
    }

    isPressed(keyCode) {
        return !!this.keys[keyCode];
    }

    onKey(keyCode, callback) {
        if (!this.listeners[keyCode]) {
            this.listeners[keyCode] = [];
        }
        this.listeners[keyCode].push(callback);
    }
}