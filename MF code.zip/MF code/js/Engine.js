import { Renderer } from './Renderer.js';
import { PhysicsEngine } from './Physics.js';
import { InputHandler } from './Input.js';
import { Inventory } from './Inventory.js';
import { UIManager } from './UI.js';
import { Player, Tree, House, Crop, ItemDrop } from './Entities.js';

export class Engine {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.renderer = new Renderer(this.canvas);
        this.physics = new PhysicsEngine();
        this.input = new InputHandler();
        this.inventory = new Inventory();
        this.ui = new UIManager(this);

        this.player = new Player(400, 300);
        this.mapWidth = 900;
        this.mapHeight = 600;

        this.houses = [
            new House(100, 80),
            new House(650, 350)
        ];

        this.trees = [
            new Tree(300, 100),
            new Tree(400, 120),
            new Tree(750, 100),
            new Tree(150, 450)
        ];

        this.crops = [
            new Crop(250, 300, 'tomate'),
            new Crop(300, 300, 'maiz'),
            new Crop(350, 300, 'trigo'),
            new Crop(250, 350, 'higo'),
            new Crop(300, 350, 'zanahoria'),
            new Crop(350, 350, 'papas')
        ];

        this.drops = [];
        this.isRunning = false;

        this.input.onKey('KeyE', () => this.handleInteraction());
    }

    start() {
        if (this.isRunning) return;
        this.isRunning = true;
        requestAnimationFrame(() => this.loop());
    }

    loop() {
        if (!this.isRunning) return;

        this.update();
        this.render();

        requestAnimationFrame(() => this.loop());
    }

    update() {
        this.player.update(this.input);
        this.physics.constrainToBounds(this.player, this.mapWidth, this.mapHeight);

        this.crops.forEach(crop => crop.update());

        this.drops = this.drops.filter(drop => {
            if (this.physics.checkCollision(this.player, drop)) {
                this.inventory.addItem(drop.itemName, drop.amount);
                return false;
            }
            return true;
        });

        let nearEntity = false;
        this.trees.forEach(tree => {
            if (tree.health > 0 && Math.abs(this.player.x - tree.x) < 50 && Math.abs(this.player.y - tree.y) < 70) {
                this.ui.showPrompt('Presiona [E] para Talar Árbol');
                nearEntity = true;
            }
        });

        this.crops.forEach(crop => {
            if (crop.stage === 2 && Math.abs(this.player.x - crop.x) < 40 && Math.abs(this.player.y - crop.y) < 40) {
                this.ui.showPrompt(`Presiona [E] para Cosechar ${crop.type}`);
                nearEntity = true;
            }
        });

        if (!nearEntity) {
            this.ui.hidePrompt();
        }
    }

    handleInteraction() {
        this.trees.forEach(tree => {
            if (tree.health > 0 && Math.abs(this.player.x - tree.x) < 50 && Math.abs(this.player.y - tree.y) < 70) {
                const chopped = tree.chop();
                if (chopped) {
                    this.drops.push(new ItemDrop(tree.x + 10, tree.y + 60, 'Madera', 2));
                    this.drops.push(new ItemDrop(tree.x + 30, tree.y + 60, 'Hojas', 3));
                    if (tree.hasFruit) {
                        this.drops.push(new ItemDrop(tree.x + 20, tree.y + 40, 'Fruto', 1));
                        tree.hasFruit = false;
                    }
                    if (tree.health === 0) {
                        this.drops.push(new ItemDrop(tree.x + 20, tree.y + 50, 'Brotes', 1));
                    }
                }
            }
        });

        this.crops = this.crops.filter(crop => {
            if (crop.stage === 2 && Math.abs(this.player.x - crop.x) < 40 && Math.abs(this.player.y - crop.y) < 40) {
                this.inventory.addItem(crop.type.charAt(0).toUpperCase() + crop.type.slice(1), 2);
                this.inventory.addItem('Semilla', 1);
                return false;
            }
            return true;
        });
    }

    render() {
        this.renderer.clear();

        this.houses.forEach(house => this.renderer.drawHouse(house));
        this.trees.forEach(tree => this.renderer.drawTree(tree));
        this.crops.forEach(crop => this.renderer.drawCrop(crop));
        this.drops.forEach(drop => this.renderer.drawItemDrop(drop));
        this.renderer.drawPlayer(this.player);
    }
}