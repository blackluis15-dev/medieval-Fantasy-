export class Inventory {
    constructor(capacity = 16) {
        this.capacity = capacity;
        this.items = {};
    }

    addItem(itemName, amount = 1) {
        if (this.items[itemName]) {
            this.items[itemName] += amount;
        } else {
            if (Object.keys(this.items).length >= this.capacity) {
                return false;
            }
            this.items[itemName] = amount;
        }
        return true;
    }

    removeItem(itemName, amount = 1) {
        if (this.items[itemName] && this.items[itemName] >= amount) {
            this.items[itemName] -= amount;
            if (this.items[itemName] <= 0) {
                delete this.items[itemName];
            }
            return true;
        }
        return false;
    }

    hasItem(itemName, amount = 1) {
        return this.items[itemName] && this.items[itemName] >= amount;
    }
}