export class UIManager {
    constructor(engine) {
        this.engine = engine;
        this.mainMenu = document.getElementById('main-menu');
        this.gameScreen = document.getElementById('game-screen');
        this.inventoryModal = document.getElementById('inventory-modal');
        this.inventoryGrid = document.getElementById('inventory-grid');
        this.prompt = document.getElementById('interaction-prompt');

        document.getElementById('start-btn').addEventListener('click', () => {
            this.mainMenu.classList.add('hidden');
            this.gameScreen.classList.remove('hidden');
            this.engine.start();
        });

        document.getElementById('inventory-btn').addEventListener('click', () => {
            this.toggleInventory();
        });

        document.getElementById('close-inventory').addEventListener('click', () => {
            this.inventoryModal.classList.add('hidden');
        });
    }

    toggleInventory() {
        if (this.inventoryModal.classList.contains('hidden')) {
            this.renderInventoryGrid();
            this.inventoryModal.classList.remove('hidden');
        } else {
            this.inventoryModal.classList.add('hidden');
        }
    }

    renderInventoryGrid() {
        this.inventoryGrid.innerHTML = '';
        const items = this.engine.inventory.items;
        
        for (let i = 0; i < 16; i++) {
            const slot = document.createElement('div');
            slot.className = 'inventory-slot';
            const itemKeys = Object.keys(items);
            
            if (i < itemKeys.length) {
                const name = itemKeys[i];
                const count = items[name];
                slot.innerHTML = `<span>${name}</span><span class="count">${count}</span>`;
            }
            this.inventoryGrid.appendChild(slot);
        }
    }

    showPrompt(text) {
        this.prompt.textContent = text;
        this.prompt.classList.remove('hidden');
    }

    hidePrompt() {
        this.prompt.classList.add('hidden');
    }
}