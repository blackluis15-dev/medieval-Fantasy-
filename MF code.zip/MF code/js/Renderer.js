export class Renderer {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
    }

    clear() {
        this.ctx.fillStyle = '#0f2b1d';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        this.ctx.fillStyle = '#143826';
        for (let x = 0; x < this.canvas.width; x += 60) {
            for (let y = 0; y < this.canvas.height; y += 60) {
                this.ctx.fillRect(x + 10, y + 10, 2, 6);
                this.ctx.fillRect(x + 40, y + 30, 3, 4);
            }
        }
    }

    drawHouse(house) {
        const ctx = this.ctx;
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.fillRect(house.x + 5, house.y + 5, house.width, house.height);

        ctx.fillStyle = '#78716c';
        ctx.fillRect(house.x, house.y + 30, house.width, house.height - 30);
        
        ctx.strokeStyle = '#57534e';
        ctx.lineWidth = 2;
        ctx.strokeRect(house.x, house.y + 30, house.width, house.height - 30);

        ctx.fillStyle = '#451a03';
        ctx.fillRect(house.x + house.width / 2 - 18, house.y + house.height - 50, 36, 50);
        ctx.strokeStyle = '#292524';
        ctx.strokeRect(house.x + house.width / 2 - 18, house.y + house.height - 50, 36, 50);

        ctx.fillStyle = '#fde047';
        ctx.fillRect(house.x + 20, house.y + 50, 24, 24);
        ctx.fillRect(house.x + house.width - 44, house.y + 50, 24, 24);
        ctx.strokeStyle = '#292524';
        ctx.strokeRect(house.x + 20, house.y + 50, 24, 24);
        ctx.strokeRect(house.x + house.width - 44, house.y + 50, 24, 24);

        ctx.fillStyle = '#991b1b';
        ctx.beginPath();
        ctx.moveTo(house.x - 15, house.y + 30);
        ctx.lineTo(house.x + house.width / 2, house.y - 10);
        ctx.lineTo(house.x + house.width + 15, house.y + 30);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#7f1d1d';
        ctx.lineWidth = 3;
        ctx.stroke();
    }

    drawTree(tree) {
        const ctx = this.ctx;
        
        ctx.fillStyle = '#5c4033';
        ctx.fillRect(tree.x + 22, tree.y + 45, 16, 45);
        ctx.fillStyle = '#3e2723';
        ctx.fillRect(tree.x + 26, tree.y + 45, 4, 45);
        ctx.fillRect(tree.x + 32, tree.y + 45, 3, 45);

        if (tree.health > 0) {
            ctx.fillStyle = '#15803d';
            ctx.beginPath();
            ctx.arc(tree.x + 30, tree.y + 35, 32, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#22c55e';
            ctx.beginPath();
            ctx.arc(tree.x + 22, tree.y + 28, 24, 0, Math.PI * 2);
            ctx.arc(tree.x + 38, tree.y + 28, 22, 0, Math.PI * 2);
            ctx.fill();

            if (tree.hasFruit) {
                ctx.fillStyle = '#ef4444';
                [
                    {x: 18, y: 25}, {x: 40, y: 20}, {x: 30, y: 40}
                ].forEach(f => {
                    ctx.beginPath();
                    ctx.arc(tree.x + f.x, tree.y + f.y, 5, 0, Math.PI * 2);
                    ctx.fill();
                });
            }
        } else {
            ctx.fillStyle = '#3e2723';
            ctx.fillRect(tree.x + 15, tree.y + 65, 30, 20);
        }
    }

    drawPlayer(player) {
        const ctx = this.ctx;
        
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.beginPath();
        ctx.ellipse(player.x + player.width / 2, player.y + player.height, 12, 6, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#2563eb';
        ctx.fillRect(player.x + 6, player.y + 14, player.width - 12, player.height - 20);
        
        ctx.fillStyle = '#78350f';
        ctx.fillRect(player.x + 6, player.y + 26, player.width - 12, 4);

        ctx.fillStyle = '#fde68a';
        ctx.beginPath();
        ctx.arc(player.x + player.width / 2, player.y + 10, 10, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#b45309';
        ctx.beginPath();
        ctx.arc(player.x + player.width / 2, player.y + 7, 10, Math.PI, Math.PI * 2);
        ctx.fill();
    }

    drawCrop(crop) {
        const ctx = this.ctx;
        
        ctx.fillStyle = '#451a03';
        ctx.fillRect(crop.x, crop.y + 10, 32, 20);
        ctx.strokeStyle = '#292524';
        ctx.strokeRect(crop.x, crop.y + 10, 32, 20);

        if (crop.stage === 0) {
            ctx.fillStyle = '#a855f7';
            ctx.fillRect(crop.x + 14, crop.y + 16, 4, 4);
        } else if (crop.stage === 1) {
            ctx.fillStyle = '#84cc16';
            ctx.fillRect(crop.x + 14, crop.y + 8, 4, 12);
        } else {
            if (crop.type === 'tomate') {
                ctx.fillStyle = '#22c55e';
                ctx.fillRect(crop.x + 10, crop.y + 2, 12, 16);
                ctx.fillStyle = '#ef4444';
                ctx.beginPath();
                ctx.arc(crop.x + 12, crop.y + 6, 4, 0, Math.PI*2);
                ctx.arc(crop.x + 20, crop.y + 12, 4, 0, Math.PI*2);
                ctx.fill();
            } else if (crop.type === 'maiz') {
                ctx.fillStyle = '#eab308';
                ctx.fillRect(crop.x + 12, crop.y - 6, 8, 22);
            } else if (crop.type === 'trigo') {
                ctx.fillStyle = '#facc15';
                ctx.fillRect(crop.x + 13, crop.y - 10, 6, 26);
            } else if (crop.type === 'higo') {
                ctx.fillStyle = '#15803d';
                ctx.beginPath();
                ctx.arc(crop.x + 16, crop.y + 5, 10, 0, Math.PI*2);
                ctx.fill();
                ctx.fillStyle = '#7c2d12';
                ctx.beginPath();
                ctx.arc(crop.x + 16, crop.y + 5, 5, 0, Math.PI*2);
                ctx.fill();
            } else if (crop.type === 'zanahoria') {
                ctx.fillStyle = '#f97316';
                ctx.beginPath();
                ctx.moveTo(crop.x + 12, crop.y + 10);
                ctx.lineTo(crop.x + 20, crop.y + 10);
                ctx.lineTo(crop.x + 16, crop.y + 22);
                ctx.closePath();
                ctx.fill();
                ctx.fillStyle = '#22c55e';
                ctx.fillRect(crop.x + 14, crop.y + 4, 4, 6);
            } else if (crop.type === 'papas') {
                ctx.fillStyle = '#a16207';
                ctx.beginPath();
                ctx.arc(crop.x + 16, crop.y + 14, 8, 0, Math.PI*2);
                ctx.fill();
            }
        }
    }

    drawItemDrop(drop) {
        const ctx = this.ctx;
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(drop.x + 8, drop.y + 8, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#b45309';
        ctx.stroke();
    }
}