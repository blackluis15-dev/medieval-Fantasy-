export class PhysicsEngine {
    constructor() {}

    checkCollision(rect1, rect2) {
        return (
            rect1.x < rect2.x + rect2.width &&
            rect1.x + rect1.width > rect2.x &&
            rect1.y < rect2.y + rect2.height &&
            rect1.y + rect1.height > rect2.y
        );
    }

    constrainToBounds(entity, mapWidth, mapHeight) {
        if (entity.x < 0) entity.x = 0;
        if (entity.y < 0) entity.y = 0;
        if (entity.x + entity.width > mapWidth) entity.x = mapWidth - entity.width;
        if (entity.y + entity.height > mapHeight) entity.y = mapHeight - entity.height;
    }
}